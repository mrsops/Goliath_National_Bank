package com.simarro.practicas.goliath_national_bank.fragments;

import com.simarro.practicas.goliath_national_bank.pojo.Movimiento;

public interface MovimientosListener  {
    void onMovimientoSeleccionado(Movimiento m);
}
