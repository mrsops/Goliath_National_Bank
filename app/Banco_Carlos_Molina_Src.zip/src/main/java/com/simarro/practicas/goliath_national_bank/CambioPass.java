package com.simarro.practicas.goliath_national_bank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.simarro.practicas.goliath_bank.R;

public class CambioPass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambio_pass);
    }
}
