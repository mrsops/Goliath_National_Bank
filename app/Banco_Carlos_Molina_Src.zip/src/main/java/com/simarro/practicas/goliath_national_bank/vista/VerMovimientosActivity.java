package com.simarro.practicas.goliath_national_bank.vista;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.simarro.practicas.goliath_bank.R;
import com.simarro.practicas.goliath_national_bank.fragments.Activity_Fragment_Movimientos;
import com.simarro.practicas.goliath_national_bank.fragments.Dialogo;
import com.simarro.practicas.goliath_national_bank.fragments.MovimientosListener;
import com.simarro.practicas.goliath_national_bank.pojo.Cuenta;
import com.simarro.practicas.goliath_national_bank.pojo.Movimiento;

public class VerMovimientosActivity extends AppCompatActivity implements MovimientosListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_movimientos);
        Activity_Fragment_Movimientos fragMovs = (Activity_Fragment_Movimientos) getSupportFragmentManager().findFragmentById(R.id.FragmentoMovimientos);
        if( fragMovs == null){
            Toast.makeText(this, "No se ha retornado nada, el fragment es null", Toast.LENGTH_SHORT).show();
        }else{
            fragMovs.setMovimientosListener(this);
        }

        Cuenta c = (Cuenta) getIntent().getSerializableExtra("Cuenta");
        
        mostrarMovimientos(c);

    }

    public void mostrarMovimientos(Cuenta c){
        Activity_Fragment_Movimientos fragMovs = (Activity_Fragment_Movimientos) getSupportFragmentManager().findFragmentById(R.id.FragmentoMovimientos);
        if (fragMovs==null){
            Toast.makeText(this, "Esto esta a null", Toast.LENGTH_SHORT).show();
        }
        fragMovs.mostrarMovimientos(c);

    }

    @Override
    public void onMovimientoSeleccionado(Movimiento m) {
        FragmentManager fragmentManager = this.getSupportFragmentManager();
        Dialogo dialogo = Dialogo.newInstance((Movimiento) m);
        dialogo.show(fragmentManager, "tagConfirmacion");


    }
}
