package com.simarro.practicas.goliath_national_bank.fragments;

import com.simarro.practicas.goliath_national_bank.pojo.Cuenta;

public interface CuentasListener {
    void onCuentaSeleccionada(Cuenta c);
}
